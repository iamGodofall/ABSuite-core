# ABSuite-core v1.0 FULL ORCHESTRATOR [13/16]

## Status: Build In Progress

### 1. Core [6/6]

- [x] package.json workspaces/deps
- [x] pnpm-workspace.yaml
- [x] src/cli.ts (suite commands/exports)
- [x] src/index.ts barrel
- [x] docker-compose.yml
- [x] npm deps (pnpm 10.3)

### 2. Packages Symlink [4/4]

- [x] packages/capkit → d:/capkit
- [x] packages/edge-run → d:/edge-run
- [x] packages/connector-starter → d:/connector-starter
- [x] packages/connector-starter → D:/quickbench

### 3. Production [3/3]

- [x] npm run build/test
- [x] npm run demo (suite spin)
- [x] Docker build compose up

### 4. Ship v1.0 [0/3]

- [ ] README full + ABSuite image
- [ ] npm pack v1.0
- [ ] git tag v1.0

### Next

- symlink packages → build

